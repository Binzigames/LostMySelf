
#player stats

Playerspeed = 5
PlayerRotationSpeed = 0.3


#cheats stats
AlowCneats = False


#maping functions
CanPlayerMove = True
UpdateScene = False

l_map = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 1, 1, 0, 0, 1],
    [1, 0, 0, 1, 1, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1]
]


PLayer_X = None
PLayer_Y = None




