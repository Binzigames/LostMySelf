import pygame
import DATA
from DATA import PLayer_X , PLayer_Y


def ChangeName(newname):
    pygame.display.set_caption("Lost my slf : " + (f"({newname})"))
    print(f"! changed name : {newname}" )


def FreezePlayer():
    DATA.CanPlayerMove = False
    print(f"! frezed player : {DATA.CanPlayerMove}")

def UnFreezePlayer():
    DATA.CanPlayerMove = True
    print(f"! unfrezed player : {DATA.CanPlayerMove}")


def update_scene(l_map , world_map):
    if l_map == world_map:
        DATA.UpdateScene = False
    else:
        DATA.UpdateScene = True


def player_position_check(X , Y):
    global PLayer_X , PLayer_Y

    if not PLayer_Y == Y or not PLayer_X == X :
        PLayer_X = X
        PLayer_Y = Y
        print(f"! pos updated : Y = {PLayer_Y} and X = {PLayer_X} ")






